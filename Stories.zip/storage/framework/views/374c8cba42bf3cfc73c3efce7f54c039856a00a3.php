<?php $__env->startSection('title'); ?>
    Edit Story | Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<style>
    .form-group{
        width: 30%
    }
</style>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h1 class="card-title">
                        Edit Story
                    </h1>
                    <form action="<?php echo e(url('edit-story/'.$pages->id)); ?>". method="POST">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <div class="form-group">
                          <label for="recipient-name" class="col-form-label">Name</label>
                        <input type="text" name='name' value="<?php echo e($pages->name); ?>" class="form-control" id="recipient-name">
                        </div>
                        <div class="form-group">
                          <label for="message-text" class="col-form-label">Profile Url</label>
                          <input type="text" value="<?php echo e($pages->profile); ?>" class="form-control" name='profile' id="profile-url"></textarea>
                        </div>
                        <div class="form-group">
                          <label for="message-text" class="col-form-label">Story Url</label>
                          <input type="text" value="<?php echo e($pages->url); ?>"  class="form-control" name='url' id="story-url"></textarea>
                        </div>
                        <div class="form-group " >
                            <p class="font-weight-normal">Type</p>
                            <select name="type" class="form-control" >
                                <option value="admin">Image</option>
                                <option value="user">Video</option>
                            </select>
                        </div>
                        <div class="modal-footer">
                            <a href="<?php echo e(url('pages')); ?>" class="btn btn-secondary" data-dismiss="modal">Cancel</a>
                            <button type="submit" class="btn btn-primary">Update</button>
                          </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Stories\resources\views/admin/pages-edit.blade.php ENDPATH**/ ?>