<?php $__env->startSection('title'); ?>
    Edit User | Admin Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h3>Edit Roles and Permissions</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                    <form action="/update-role/<?php echo e($users->id); ?>" method="POST">
                            <?php echo e(csrf_field()); ?>

                            <?php echo e(method_field('PUT')); ?>

                            <div class="form-group">
                                <p class="font-weight-normal"> Name</p>
                                <input type="text" class="form-control" value="<?php echo e($users->name); ?>" name="username">
                            </div>
                            <div class="form-group " >
                                <p class="font-weight-normal">Give Role</p>
                                <select name="usertype" class="form-control">
                                    <option value="admin">Admin</option>
                                    <option value="user">User</option>
                                    <option value="vendor">Vendor</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success">Update Role</button>
                            <a href="/add-roles" class="btn btn-danger">Cancel</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Stories\resources\views/admin/role-edit.blade.php ENDPATH**/ ?>